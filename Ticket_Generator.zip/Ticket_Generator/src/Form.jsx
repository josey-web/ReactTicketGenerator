import { useState } from "react";

// Cloudinary API URL (use your own credentials here)
const CLOUDINARY_UPLOAD_URL =
  "https://api.cloudinary.com/v1_1/duyhcrcn4/image/upload";
const CLOUDINARY_UPLOAD_PRESET = "yn_hytgn1";

function Form() {
  const [fullName, setFullName] = useState("");
  const [email, setEmail] = useState("");
  const [phoneNo, setPhoneNo] = useState("");
  const [aboutProject, setAboutProject] = useState("");
  const [avatar, setAvatar] = useState(null); // Avatar URL from Cloudinary
  const [errors, setErrors] = useState({});
  const [ticket, setTicket] = useState(null);
  const [loading, setLoading] = useState(false);
  const [progress, setProgress] = useState(0);

  // Handle input change
  const handleChange = (e) => {
    const { name, value } = e.target;
    if (name === "fullName") setFullName(value);
    if (name === "email") setEmail(value);
    if (name === "phoneNo") setPhoneNo(value);
    if (name === "about-project") setAboutProject(value);
  };

  // Handle form submission
  const handleFormSubmit = async (e) => {
    e.preventDefault();
    const validationErrors = validateForm();
    setErrors(validationErrors);
    if (Object.keys(validationErrors).length === 0) {
      try {
        const imageURL = await uploadImageToCloudinary();
        if (imageURL) {
          setAvatar(imageURL);
          generateTicket(imageURL);
        }
      } catch (error) {
        alert("Failed to upload image. Please try again.");
      }
    }
  };

  // Validate form fields
  const validateForm = () => {
    const errors = {};
    if (!fullName) errors.fullName = "Name is required";
    if (!email) errors.email = "Email is required";
    else if (!/\S+@\S+\.\S+/.test(email)) errors.email = "Email is invalid";
    if (!phoneNo) errors.phoneNo = "Phone number is required";
    else if (!/^\d{11}$/.test(phoneNo))
      errors.phoneNo = "Phone number is invalid (must be 11 digits)";
    if (!aboutProject) errors.aboutProject = "About the project is required";
    return errors;
  };

  // Upload image to Cloudinary
  const uploadImageToCloudinary = async () => {
    const fileInput = document.getElementById("fileInput");
    const file = fileInput.files[0];
    if (!file) return null;

    const formData = new FormData();
    formData.append("file", file);
    formData.append("upload_preset", CLOUDINARY_UPLOAD_PRESET);

    try {
      setLoading(true);
      const response = await fetch(CLOUDINARY_UPLOAD_URL, {
        method: "POST",
        body: formData,
        onUploadProgress: (event) => {
          if (event.lengthComputable) {
            const progressPercentage = (event.loaded / event.total) * 100;
            setProgress(progressPercentage);
          }
        },
      });
      const data = await response.json();
      setLoading(false);
      setProgress(0);
      return data.secure_url;
    } catch (error) {
      setLoading(false);
      console.error("Cloudinary upload failed:", error);
      throw new Error("Image upload failed");
    }
  };

  // Generate ticket
  const generateTicket = (imageURL) => {
    const serialNumber = Math.floor(Math.random() * 1000000);
    const ticketData = {
      fullName,
      email,
      phoneNo,
      aboutProject,
      avatar: imageURL,
      serialNumber,
    };
    setTicket(ticketData);
  };

  // Handle image drop
  const handleDrop = (e) => {
    e.preventDefault();
    e.stopPropagation(); // Prevent the event from bubbling up
    const file = e.dataTransfer.files[0];
    if (file) {
      const fileInput = document.getElementById("fileInput");
      fileInput.files = e.dataTransfer.files;
      handleImageUpload(file);
    }
  };

  // Handle image file selection
  const handleFileSelect = (e) => {
    const file = e.target.files[0];
    handleImageUpload(file);
  };

  // Upload the selected image
  const handleImageUpload = async (file) => {
    if (file) {
      try {
        const imageURL = await uploadImageToCloudinary();
        setAvatar(imageURL);
      } catch (error) {
        console.error("Error uploading image:", error);
      }
    }
  };

  const handleGenerateNewTicket = () => {
    // Reset state to allow for new ticket generation
    setTicket(null);
    setFullName("");
    setEmail("");
    setPhoneNo("");
    setAboutProject("");
    setAvatar(null);
    setErrors({});
  };

  const handleDownloadTicket = () => {
    // Create a downloadable ticket PDF or image (this is a placeholder)
    const ticketContent = `
      Ticket for ${ticket.fullName}
      Email: ${ticket.email}
      Phone: ${ticket.phoneNo}
      About Project: ${ticket.aboutProject}
      Serial Number: ${ticket.serialNumber}
      Avatar: ${ticket.avatar}
    `;
    const blob = new Blob([ticketContent], { type: "text/plain" });
    const link = document.createElement("a");
    link.href = URL.createObjectURL(blob);
    link.download = "ticket.jpg";
    link.click();
  };

  return (
    <div>
      {!ticket ? (
        <form onSubmit={handleFormSubmit} noValidate>
          <div className="last-container">
            <div className="form-container">
              {/* Image Upload Area (Click or Drag & Drop on container-3) */}
              <div className="container-1">
                <div className="upload-text-container">
                  <p className="upload-text">Upload Profile Picture</p>
                </div>
                {/* Image Preview inside container-1 */}
                <div className="container-2">
                  <div
                    className="container-3"
                    onClick={() => document.getElementById("fileInput").click()}
                    onDrop={handleDrop}
                    onDragOver={(e) => e.preventDefault()} // Allow the drop
                    data-testid="image-upload-area"
                  >
                    {!avatar ? (
                      <>
                        <i className="fa-solid fa-cloud-arrow-up"></i>
                        <p className="upload-text">
                          Drag & drop or <br />
                          click to upload
                        </p>
                      </>
                    ) : (
                      <img
                        src={avatar}
                        alt="Uploaded Avatar"
                        className="avatar-img"
                        style={{
                          width: "100%",
                          height: "100%",
                          objectFit: "cover", // Ensure image covers the div without stretching
                        }}
                      />
                    )}
                  </div>
                </div>
              </div>

              <input
                type="file"
                id="fileInput"
                style={{ display: "none" }}
                accept="image/*"
                onChange={handleFileSelect}
                data-testid="file-input"
              />

              {/* Progress Bar */}
              {loading && (
                <div className="progress-container">
                  <div
                    className="progress-bar"
                    style={{ width: `${progress}%` }}
                    data-testid="progress-bar"
                  ></div>
                </div>
              )}

              <hr className="divided-line" />
              <div className="input-element-wrapper">
                {/* Form Fields */}
                <div className="input-group">
                  <label htmlFor="fullName">
                    Name <span className="required">*</span>
                  </label>
                  <input
                    type="text"
                    id="fullName"
                    name="fullName"
                    value={fullName}
                    onChange={handleChange}
                    data-testid="fullName"
                    required
                    placeholder="Enter your name"
                  />
                  {errors.fullName && (
                    <p className="error">{errors.fullName}</p>
                  )}
                </div>

                <div className="input-group">
                  <label htmlFor="email">
                    Email <span className="required">*</span>
                  </label>
                  <input
                    type="email"
                    id="email"
                    name="email"
                    value={email}
                    onChange={handleChange}
                    data-testid="email"
                    required
                    placeholder="Enter your email"
                  />
                  {errors.email && <p className="error">{errors.email}</p>}
                </div>

                <div className="input-group">
                  <label htmlFor="phoneNo">
                    Phone No <span className="required">*</span>
                  </label>
                  <input
                    type="tel"
                    id="phoneNo"
                    name="phoneNo"
                    value={phoneNo}
                    onChange={handleChange}
                    data-testid="phoneNo"
                    required
                    placeholder="Enter your phone number"
                  />
                  {errors.phoneNo && <p className="error">{errors.phoneNo}</p>}
                </div>

                <div className="input-group">
                  <label htmlFor="about-project">About the project</label>
                  <textarea
                    className="about-project"
                    name="about-project"
                    id="about-project"
                    value={aboutProject}
                    onChange={handleChange}
                    data-testid="aboutProject"
                    placeholder="Write here..."
                  ></textarea>
                  {errors.aboutProject && (
                    <p className="error">{errors.aboutProject}</p>
                  )}
                </div>
              </div>

              {/* Button Group */}
              <div className="button-group">
                <button
                  className="back-btn"
                  type="button"
                  onClick={() => window.history.back()}
                  data-testid="back-btn"
                >
                  Back
                </button>
                <button
                  className="get-ticket-btn"
                  type="submit"
                  data-testid="get-ticket-btn"
                >
                  Get My Free Ticket
                </button>
              </div>
            </div>
          </div>
        </form>
      ) : (
        <div className="ticket-container-1">
          {/* start */}
          <div className="div-A"></div>

          <div className="ticket-wrapper">
            <h2 className="conf-heading-text">HNG12 Conference Ticket</h2>
            <div className="avatar-section">
              <div className="avatar-preview">
                <img
                  alt="Uploaded Avatar"
                  src={ticket.avatar}
                  className="gen-avatar-img"
                />
              </div>
              <div className="personal-details">
                <div className="detail-heading">
                  <p> Full Name:</p>
                  <span>{ticket.fullName}</span>
                </div>
                <div className="detail-heading">
                  <p> Phone No:</p>
                  <span>{ticket.phoneNo}</span>
                </div>
                <div className="detail-heading">
                  <p> Email:</p>
                  <span>{ticket.email}</span>
                </div>
              </div>
            </div>

            <div className="gen-about-project">
              <div className="About-the-Project">
                <p>
                  <span className="about-text">About the Project:</span>
                </p>
              </div>
              <p>{ticket.aboutProject}</p>
            </div>

            {/* ticket serial number .....................*/}
            <div className="serial-number-wrapper">
              <p>
                Ticket Serial Number: <span>{ticket.serialNumber}</span>
              </p>
            </div>
          </div>

          <div className="divided-div"></div>

          {/* buttons .................................*/}
          <div className="ticket-button-group">
            <button
              className="download-btn"
              type="button"
              onClick={handleDownloadTicket}
            >
              Download Ticket
            </button>
            <button
              className="generate-another-btn"
              type="button"
              onClick={handleGenerateNewTicket}
            >
              Generate Another Ticket
            </button>
          </div>
          {/* end*/}
        </div>
      )}
    </div>
  );
}

export default Form;
