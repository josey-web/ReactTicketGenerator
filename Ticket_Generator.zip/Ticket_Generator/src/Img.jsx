// function Img() {
//   return (
//     <>
//       <div className="container-1">
//         <div className="upload-text-container">
//           <p className="uploade-text">Upload Profile Picture</p>
//         </div>
//         <div className="container-2">
//           <div className="container-3">
//             <i className="fa-solid fa-cloud-arrow-up"></i>
//             <p className="upload-text">
//               Drag & drop or <br />
//               click to upload
//             </p>
//           </div>
//         </div>
//       </div>
//     </>
//   );
// }

// export default Img
