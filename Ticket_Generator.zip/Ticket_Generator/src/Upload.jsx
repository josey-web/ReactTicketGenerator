import { useState } from "react";




const ImageUpload = () => {

  const [isloggedIn, setInLoggedIn] = useState(false)


  function handleLogg() {

    if (isloggedIn) {
      button
    }
    setInLoggedIn(true)
    

}



  

  return (
    <div>

      {
        isloggedIn ? (
        <div>
          <h1>Welcome to the Image Upload App!</h1>
          {/* Add your form here */}
        </div>
        ) : (
            <div>
              <h1>Please Login to Upload Images</h1>
              {/* Add your login form here */}

              <form>
                <label>
                  Username:
                  <input type="text" name="username" />
                </label>
                <label>
                  Password:
                  <input type="password" name="password" />
                </label>
                <input type="submit" value="Submit" />
              </form>

              {/* Add your registration form here */}
            </div>
        )
      }




      <button onClick={handleLogg}>Login</button>
    </div>
  );
};

export default ImageUpload;
