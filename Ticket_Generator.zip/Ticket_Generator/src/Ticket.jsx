function Ticket() {
  return (

    <div className="ticket-container-1">
      
        <div className="div-A"></div>

      <div className="ticket-wrapper">
        <h2 className="conf-heading-text">HNG12 Conference Ticket</h2>
        <div className="avatar-section">
          <div className="avatar-preview">
            <img
              alt="Uploaded Avatar"
              src="https://avatar.iran.liara.run/public"
              className="gen-avatar-img"
            />
          </div>
          <div className="personal-details">
            <div className="detail-heading">
              <p> Full Name:</p>
              <span>Jose Jose</span>
            </div>
            <div className="detail-heading">
              <p> Phone No:</p>
              <span>8787878787</span>
            </div>
            <div className="detail-heading">
              <p> Email:</p>
              <span>jogjhj@gmail.com</span>
            </div>
          </div>
        </div>

        <div className="gen-about-project">
          <div className="About-the-Project">
            <p>
              <span className="about-text">About the Project:</span>
            </p>
          </div>
          <p>
            Lorem ipsum dolor tur adipisicing elit. Dolorem in
            voluptates rei hic tempora
            temporibus tempore!
          </p>
        </div>

        {/* ticket serial number .....................*/}
        <div className="serial-number-wrapper">
          <p>
            Ticket Serial Number: <span>45RTTTGGT</span>
          </p>
        </div>
      </div>

      <div className="divided-div"></div>

      {/* buttons .................................*/}
      <div className="ticket-button-group">
        <button className="download-btn" type="button">
          Download Ticket
        </button>
        <button className="generate-another-btn" type="button">
          Generate Another Ticket
        </button>
      </div>
    </div>
      
  );
}

export default Ticket;
