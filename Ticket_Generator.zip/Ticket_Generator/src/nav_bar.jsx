import { useState } from "react";

function Nav_bar() {
  const [activeTab, setActiveTab] = useState(0);

  // const handleTab = (index) => {
  //   setActiveTab(index);
  // };

  return (
    <>
      <nav>
        <div className="nav-menu">
          <li>
            <a
              href=""
              onClick={(e) => {
                e.preventDefault();
                setActiveTab(0);
              }}
              className={activeTab === 0 ? "active" : "inactive"}
            >
              Events
            </a>
          </li>

          <li>
            <a
              href=""
              onClick={(e) => {
                e.preventDefault();
                setActiveTab(1);
              }}
              className={activeTab === 1 ? "active" : "inactive"}
            >
              My Ticket
            </a>
          </li>
          <li>
            <a
              href=""
              onClick={(e) => {
                e.preventDefault();
                setActiveTab(2);
              }}
              className={activeTab === 2 ? "active" : "inactive"}
            >
              About Event
            </a>
          </li>
        </div>
      </nav>
    </>
  );
}

export default Nav_bar;
