// import { useState } from 'react'

import './App.css'
import Form from './Form';


import Nav_bar from './nav_bar';
// import ImageUpload from './Upload';
// import Ticket from './Ticket';

function App() {


  return (
    <>
      <Nav_bar />
{/* <Ticket/> */}
      <Form />
      {/* <ImageUpload/> */}
    </>
  );
}

export default App
